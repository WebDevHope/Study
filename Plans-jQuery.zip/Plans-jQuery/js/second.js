var mylistObj = {
    buttons   : {
        checkedAll       : $('.checkedAll').click(function(){
            $("input[type=checkbox]").prop("checked", true);
            $("input[type=checkbox]").addClass("checked");
        }),
        uncheckedAll     : $('.uncheckedAll').click(function(){
            $("input[type=checkbox]").prop("checked", false);
            $("input[type=checkbox]").removeClass("checked");
        }),
        deleteChecked    : $('.deleteChecked').click(function(){
            $('.checked').parent().remove();
        }),
        inputAdd         : $('.inputAdd').click(function(){
            mylistObj.innerToList()
        })
    },
    myInput   : $('.mainInput'),
    myOl      : $('.myOl'),
    listItmIndex : 0,
    innerToList : function () {
        var tempLi         = $(document).append("<li></li>");
        var tempDiv        = $(document).append("<div></div>>");
        var tempDivText    = $(document).append("<span></span>>");
        var checkBox       = $(document).append("<input>");
        var dellFromLine   = $(document).append("<button>");
        $(tempLi).addClass('tempLi');
        $(dellFromLine).html('X');
        $(dellFromLine).addClass("dellFromLine")
        $(dellFromLine).click(function () {
            tempLi.remove()
        })
        $(checkBox).attr("type", "checkbox");
        $(checkBox).click(function () {
            console.log($(checkBox).hasClass("checked") === true)
            if($(checkBox).hasClass("checked") === true){
                $(checkBox).removeClass("checked");
            } else {
                $(checkBox).addClass("checked")
            }
        });
        $(tempDiv).addClass("textField");
        $(tempDiv).dblclick(function(){
            $(tempDiv).parent().css({borderBottom : "solid 1px red"})
            var inpAfterClick = document.createElement("input");
            var buttonAfterClick = document.createElement("button");
            $(inpAfterClick).val($(tempDivText).text());
            $(inpAfterClick).addClass("inpAfterClick");
            $(buttonAfterClick).html('X');
            $(buttonAfterClick).addClass('buttonAfterClick');

            $(buttonAfterClick).click( function () {
                $(tempDivText).text($(inpAfterClick).val());
                $(inpAfterClick).remove();
                tempDiv.append(tempDivText);
                $(buttonAfterClick).remove()
                $(tempDiv).parent().css({borderBottom : "solid 1px #27d6d6"})
            })
            tempDivText.remove();
            tempDiv.append(inpAfterClick);
            tempLi.append(buttonAfterClick);
        })
        tempDivText.append(this.myInput.val());
        this.myOl.append(tempLi);
        tempLi.append(checkBox);
        tempLi.append(tempDiv);
        tempDiv.append(tempDivText);
        tempLi.append(dellFromLine);

    },
}

